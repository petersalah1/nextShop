import api from "@/lib/axios";

export async function getBrands() {
  const response = await api.get('/api/v1/brands');

  return response.data
}