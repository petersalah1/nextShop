'use client';
import { useBrands } from '@/hooks/queries/useBrands';
import Link from 'next/link';

function Brands() {
  const { data: brandsResponse, isError, isLoading } = useBrands();
  const allBrand = brandsResponse?.data || [];
  const allBrands = allBrand?.slice(0, 8);
  console.log(allBrands);

  return (
    <>
      <section className="px-6 max-w-7xl mx-auto ">
        <div className="flex justify-between">
          <div className="">
            <h4 className="text-(--primary) font-semibold">Our Brands</h4>
            <h2 className="my-3 text-4xl font-bold">Featured Brands</h2>
            <p className="text-gray-500 mb-7">Discover our latest selected brands with great prices and fast delivery.</p>
          </div>
        <Link href="/brands" className='mt-20 border border-gray-300 bg-white/10 h-12 p-3 rounded-4xl hover:border-(--primary) hover:text-(--primary) transition'>All Brands</Link>
        </div>
        <section className="grid gap-5 grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {allBrands?.map((brand) => (
            <Link href={`/brands/${brand._id}`} className="bg-white p-10 text-center rounded-lg shadow hover:shadow-2xl shadow-black transition" key={brand._id}>
              <img src={brand.image} alt={brand.name} className="w-full p-5 py-10 bg-gray-50 rounded-2xl mb-5" />
              <h2>{brand.name}</h2>
            </Link>
          ))}
        </section>
      </section>
    </>
  );
}

export default Brands;
