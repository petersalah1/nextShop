'use client';
import { useBrands } from '@/hooks/queries/useBrands';
import Link from 'next/link';

function BrandsList() {
  const { data: brandsResponse, isError, isLoading } = useBrands();
  const allBrands = brandsResponse?.data || [];
  // console.log(allBrands);

  return (
    <>
      <main className="min-h-screen bg-white px-4 py-16 sm:px-6 lg:px-8">
        <section className="mx-auto max-w-7xl">
          <section className="grid gap-5 grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {allBrands?.map((brand) => (
              <Link href={`/brands/${brand._id}`} className="bg-white p-10 text-center rounded-lg shadow hover:shadow-2xl shadow-black transition" key={brand._id}>
                <img src={brand.image} alt={brand.name} className="w-full p-5 py-10 bg-gray-50 rounded-2xl mb-5" />
                <h2>{brand.name}</h2>
              </Link>
            ))}
          </section>
        </section>
      </main>
    </>
  );
}

export default BrandsList;
